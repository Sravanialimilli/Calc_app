# Calc_app
Creating calculator app 
